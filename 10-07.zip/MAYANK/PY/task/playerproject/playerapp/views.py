from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from .models import Player

# Home Page: Shows all players & filters search results
def home(request):
    search_query = request.GET.get('search', '')
    if search_query:
        players = Player.objects.filter(name__icontains=search_query)
    else:
        players = Player.objects.all()
    
    return render(request, 'home.html', {'players': players, 'search_query': search_query})

# Welcome Page: Static student message
def welcome(request):
    return render(request, 'welcome.html')

# Add Player Page
def add_player(request):
    if request.method == "POST":
        name = request.POST.get('name')
        innings = request.POST.get('innings')
        runs = request.POST.get('runs')
        
        player=Player.objects.create(name=name, test_innings=innings, runs=runs)
        player.save()
        return redirect('home')
    return render(request, 'add_player.html')

# Edit Player Page
def edit_player(request, pk):
    player = get_object_or_404(Player, pk=pk)
    if request.method == "POST":
        player.name = request.POST.get('name')
        player.test_innings = request.POST.get('innings')
        player.runs = request.POST.get('runs')
        player.save()
        return redirect('home')
    return render(request, 'edit_player.html', {'player': player})

# Delete Player logic
def delete_player(request, pk):
    player = get_object_or_404(Player, pk=pk)
    player.delete()
    return redirect('home')