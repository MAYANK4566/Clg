from rest_framework import serializers
from .models import User,Movie

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields = "__all__"

class UserSerializerMovie(serializers.ModelSerializer):
    class Meta:
        model=Movie
        fields="__all__"