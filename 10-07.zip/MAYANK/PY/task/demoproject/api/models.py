from django.db import models

# Create your models here.
class User(models.Model):
    age=models.IntegerField()
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Movie(models.Model):
    title=models.CharField( max_length=100)
    director = models.CharField(max_length=100)
    release_year=models.IntegerField()

    def __str__(self):
        return self.title