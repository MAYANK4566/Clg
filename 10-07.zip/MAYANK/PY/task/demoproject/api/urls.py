from django.urls import path
from api import views

urlpatterns=[
    path('user/',views.get_user,name="get_user"),
    path('user/create/',views.create_user,name="create_user"),
    path('user/<int:pk>',views.user_detail,name="user_detail"),
    path('movies/',views.get_post,name="get_post"),
    path('movies/<int:pk>',views.movies_detail,name="movies_detail"),
]