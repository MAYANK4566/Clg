from api import views
from django.urls import path

urlpatterns = [
    path("users/",views.get_user,name='get_user'),
    # path('users/create/',views.create_user,name='create_user'),
    # path('user/<int:pk>',views.user_detail,name='user_detail'),
]
