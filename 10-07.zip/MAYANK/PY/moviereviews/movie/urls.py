from django.urls import path
from movie import views as movieviews

urlpatterns = [ 
    path("<int:movie_id>",movieviews.detail,name="detail"),
    path("<int:movie_id>/create",movieviews.createreview,name="createreview"),
    path("review/<int:review_id>",movieviews.updatereview,name="updatereview"),
    path("review/<int:review_id>/delete",movieviews.deletereview,name="deletereview"),
]   