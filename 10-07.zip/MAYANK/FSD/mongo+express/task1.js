const expr = require("express");
const app = expr();
const mg = require("mongoose");

mg.connect("mongodb://127.0.0.1:27017/mgb6")
  .then(() => {
    console.log("Success");
  })
  .catch((e) => {
    console.log(e);
  });

const myschema = new mg.Schema({
    username:String,password:String,city:String,text:String
})

const mymodel = new mg.model("logindata",myschema)

app.use(expr.static(__dirname,{index:"task1.html"}))
app.get("/submit", async (req, res) => {
    const data = new mymodel({
        username: req.query.uname,
        password: req.query.pass,
        city: req.query.city,
        text: req.query.textarea,
    })
    await data.save()
    res.send(`Welcome ${req.query.uname}`)
})
app.listen(4566);