// npm i validator
const mg = require("mongoose");
const validator = require("validator");
mg.connect("mongodb://127.0.0.1:27017/mgb6")
  .then(() => {
    console.log("Success");
  })
  .catch((e) => {
    console.log(e);
  });

const myschema = new mg.Schema({
  pname: {
    type: String,
    required: true,
    trim: true,
    uppercase: true,
    minlength: 4,
    maxlength: 8,
    validate: [validator.isAlphanumeric, "Sachu Lakhne Namunaaa"],
  },
  qty: { type: Number, min: 1, max: 5 },
  email: {
    type: String,
    validate: [validator.isEmail, "Taru Mail Deneeeeee"],
    unique: true,
  },
  role: { type: String, enum: ["Seller", "Buyer"], default: "Seller" },
});

mg.pluralize(null);
const mymodel = new mg.model("products", myschema);

const myfun = async () => {
  try {
    const data = new mymodel({
      pname: "XYZZ",
      email: "xyz@gmail.com",
      qty: 3
    });
    const result = await data.save();
    console.log(result);
  } catch (e) {
    console.log(e);
  }
};
myfun();
