const mg = require("mongoose");
mg.connect("mongodb://127.0.0.1:27017/mgb6")
  .then(() => {
    console.log("Success");
  })
  .catch((e) => {
    console.log(e);
  });

const userschema = new mg.Schema({
    username: {
        type: String, required: [true, "User Name is require"], maxlength: 20, minlength: 4, match: /[A-Za-z]+[0-9]+$/, uppercase: true, trim: true
    },
    email: {
        type: String, required: true, unique: true, match: /\S+@\S+\.\S+/
    },
    age: {
        type: Number, min: 18, max: 45
    },
    role: {
        type: String, enum: ["user", "admin"], default: "user"
    }
},{
    versionKey: false
}
);

mg.pluralize(null);

const mymodel = new mg.model("user", userschema);

const myfun = async () => {
    try {
        const data = [
            {
                username : "Abc12",
                email: "abc12@gmail.com",
                age: 20,
                role:"admin"
                },
                {
                username : "Xyz99",
                email: "xyz99@gmail.com",
                age: 44
            }
        ]
        const result = await mymodel.insertMany(data)
        console.log(result);
    } catch (e) {
        console.log(e);
    }
}

myfun();