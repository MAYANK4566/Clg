// npm i validator
const mg = require("mongoose");
const validator = require("validator");
mg.connect("mongodb://127.0.0.1:27017/mgb6")
  .then(() => {
    console.log("Success");
  })
  .catch((e) => {
    console.log(e);
  });

const myschema = new mg.Schema({
  course: { type: String },
  cat: { type: String },
  fees: { type: Number },
  instructor: { type: String },
  active: { type: Boolean },
  duration: { type: Number },
  mode: { type: String, enum: ["Online", "Offline"] },
});

mg.pluralize(null);
const mymodel = new mg.model("courses", myschema);

const myfun = async () => {
  try {
    const c = [
      {
        course: "MERN",
        cat: "web devlopment",
        fees: 25000,
        instructor: "ABC",
        active: true,
        duration: 3,
        mode: "Offline",
      },
      {
        course: "Python",
        cat: "Programming",
        fees: 18000,
        instructor: "XYZ",
        active: true,
        duration: 3,
        mode: "Online",
      },
      {
        course: "Data Science",
        cat: "Data Analytics",
        fees: 28000,
        instructor: "PQR",
        active: false,
        duration: 4,
        mode: "Offline",
      },
      {
        course: "ML",
        cat: "AI",
        fees: 30000,
        instructor: "DEF",
        active: true,
        duration: 6,
        mode: "Offline",
      },
      {
        course: "UI/UX Design",
        cat: "Design",
        fees: 28000,
        instructor: "MNO",
        active: false,
        duration: 4,
        mode: "Online",
      },
    ];
    // const result = await mymodel.insertMany(c)
    // console.log(result);

    // const t1 = await mymodel.findOne({ instructor: "MNO" });
    // console.log(t1._id);

    // const t2 = await mymodel.findByIdAndUpdate(t1._id, {
    //   $set: { fees: 25000, duration: 3 },
    // });
    // console.log(t2);

    // const t3 = await mymodel.findByIdAndDelete(t1._id);
    // console.log(t3);

    // const t4 = await mymodel
    //   .find({}, { course: 1, fees: 1, duration: 1 })
    //   .sort({ fees: -1 });
    // console.log(t4[1]);

    // const t5 = await mymodel.updateOne(
    //   { course: "Cloude Computing" },
    //   { $set: { fees: 22000, duration: 3, mode: "Online" } },
    //   { upsert: true },
    // );
    // console.log(t5);

    // const t6 = await mymodel.find({ mode: "Offline", fees:{$lt:25000}});
    // console.log(t6);

    // const t7 = await mymodel.find({
    //   $and: [{ active: true }, { duration: { $gte: 3 } }],
    //   $nor: [{ mode: "Online" }],
    // });
    // console.log(t7);

    //   const t8 = await mymodel.aggrefrate([{ $match: { active: true, mode: "Online" } }, { $group: { _id: "$course", coursetotal: { $sum: 1 } } },

    // ])
  } catch (e) {
    console.log(e);
  }
};
myfun();
