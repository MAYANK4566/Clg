const mg = require("mongoose");
mg.connect("mongodb://127.0.0.1:27017/mgb6")
  .then(() => {
    console.log("Success");
  })
  .catch((e) => {
    console.log(e);
  });

let myschema = new mg.Schema(
  {
    username: String,
    email: { type: String, required: true },
    age: Number,
    active: Boolean,
    doj: { type: Date, default: new Date().toLocaleDateString() },
  },
  { strict: true, versionKey: false },
);

mg.pluralize(null);

const mymodel = new mg.model("person", myschema);

const myfun = async () => {
  try {
    const data = [
      {
        username: "ABC",
        email: "abc@gmail.com",
        age: 30,
        active: true,
      },
      {
        username: "DEF",
        email: "def@gmail.com",
        age: 31,
        active: false,
      },
      {
        username: "GHI",
        email: "ghi@gmail.com",
        age: 32,
        active: true,
        city: "ahm",
      },
    ];
    const result = await mymodel.insertMany(data);
    console.log(result);
  } catch (e) {
    console.log(e);
  }
};
myfun();
