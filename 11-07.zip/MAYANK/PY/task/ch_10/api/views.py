from django.shortcuts import render
from rest_framework import viewsets
from .serializers import ProjectSerializers
from .models import Project
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from .pagination import ProjectPagination

# Create your views here.
class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializers
    pagination_class = ProjectPagination
    permission_classes= [IsAuthenticatedOrReadOnly]
