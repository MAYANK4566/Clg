const expr = require("express")
const app = expr()
const mg = require("mongoose")
const cors = require("cors")
app.use(cors());
app.use(expr.json());

mg.connect("mongodb://127.0.0.1:27017/mgb6")
  .then(() => {
    console.log("Success");
  })
  .catch((e) => {
    console.log(e);
  });

const myschema = new mg.Schema({
  username: String,message:String
});

const mymodel = new mg.model("reacdata", myschema);

app.post("/signup", async(req, res) => {
    try {
        const { username, message } = req.body;
        const data= new mymodel({username:username,message:message})
        await data.save()
        res.send()
    } catch (e) {
        console.log(e);
    }
})
app.listen(5000)