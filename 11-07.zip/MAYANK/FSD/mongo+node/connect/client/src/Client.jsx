import { useState } from "react";
import axios from "axios";

export default function Client() {
    const [username, setusername] = useState("");
    const [message, setmsg] = useState("");
    const handlesubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:5000/signup", {username, message});
            alert(`Wellocme ${username}`)
            setusername("");
            setmsg("");
        } catch (e) {
            console.log(e);
        }
    }
    return (
        <form onSubmit={handlesubmit}>
            <input type="text" value={username} placeholder="username" onChange={(e)=>{setusername(e.target.value)}}/>
            <textarea value={message} onChange={(e) => { setmsg(e.target.value) }}></textarea>
            <input type="submit"/>
        </form>
        // <h3>{username}</h3>
        // <h4>{message}</h4>
    )
}