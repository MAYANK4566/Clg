import streamlit as st
st.set_page_config(page_title="Streamlit 2",page_icon="🤸‍♂️",layout="wide")
name = st.sidebar.text_input("Enter Your Name:")
dep = st.sidebar.selectbox("Department:",['CES','CE','AI&ML','AT'])
exp = st.sidebar.slider("Your Experience : ",0,40,10)
col1,col2 = st.columns([1,2])
with col1:
    st.text("Basic information")
    st.markdown(f"**Name** : {name}")
    st.markdown(f"**Department** : {dep}")
    st.markdown(f"**Experience** : {exp}")
with col2:
    st.subheader("About")
    st.write("*****")
with st.expander("Subject Taught"):
    st.write("PY-1")
    st.write("PS")
    st.write("DE")
    st.write("FSD-1")