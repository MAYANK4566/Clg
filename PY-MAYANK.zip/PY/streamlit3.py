import streamlit as st
st.set_page_config(page_title="Streamlit 3",page_icon="🌈",layout="wide")
st.title("Text Input Demo.")
name = st.text_input("Enter Your Name:")
com = st.text_area("Any Comments/Feedback:")
st.write("Live Output:")
if name:
    st.write(f"Hello **{name}!**")
if com:
    st.write("Your Comments:")
    st.write(f"***{com}***")