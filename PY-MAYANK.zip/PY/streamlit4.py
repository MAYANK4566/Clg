import streamlit as st
st.set_page_config(page_title="Streamlit 4",page_icon="🌈",layout="wide")
st.title("Number Input Demo.")
num = st.number_input("Enter your age : ",min_value=5,max_value=50)
ran = st.slider("Give Rating: ",0,10,5,step=2)
st.write(num)