import streamlit as st
st.set_page_config(page_title="Streamlit 1",page_icon="🎅",layout="wide")
st.title("This is Title.")
st.header("This is Header.")
st.write("This is Write.")
st.text("This is Text.")
st.markdown("###### This is Markdown.")
code = """
#Sum of 2-int Values 
def add(a,b):
    return a+b
print("A+B : ",add(10,20))
"""
st.markdown("###### This Code with Colors:")
st.code(code,language="python")
st.markdown("###### This Code without Colors:")
st.code(code,language="C")