import streamlit as st
st.set_page_config(page_title="Number Input", page_icon="😎",layout="wide")
st.title("Number Input Demo")
age  = st.number_input("Enter your Age :",min_value=0,max_value=80,value=25)
s = st.slider("Give Ratings :",min_value=0,max_value=10,value=7,step=2)

st.write("Live Output :")
if age:
    st.write(f"**Age** : {age}")
