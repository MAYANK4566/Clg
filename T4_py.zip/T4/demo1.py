import streamlit as st
st.set_page_config(page_title="User Information", page_icon="😎",layout="wide")
st.title("Text Input Demo")
name  = st.text_input("Enter your Name :")
comments = st.text_area("Any Comments/Feedback :")

st.write("Live Output :")
if name:
    st.write(f"**Name** : {name}")
if comments:
    st.write("Your comments :")
    st.write(comments)
