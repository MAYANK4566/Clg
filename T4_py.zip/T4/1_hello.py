import streamlit as st
st.set_page_config(page_title="Hello Everyone", page_icon="😎",layout="centered")
st.title("Welcome to Streamlit")
st.header("This is header")
st.subheader("This is subheader")
st.markdown("This is markdown")
code = '''
def add(a,b):
    return a+b
print(add(5,5))'''
st.code(code,language = "python")
st.code(code,language = "C")
