import streamlit as st
st.set_page_config(page_title="User Information", page_icon="😎",layout="wide")
st.title("User Profile")
st.sidebar.title("Profile Setting")
name = st.sidebar.text_input("Enter your name","Deep Patel")
dept = st.sidebar.selectbox("Enter your Department",["CSE","CE","IT","AIML"])
year = st.sidebar.slider("Enter year",1,4,2)
st.sidebar.markdown("---")
col1, col2 = st.columns([1,2])
with col1:
    st.subheader("User Information")
    st.write(f"**Name** : {name}")
    st.write(f"**Department** : {dept}")
    st.write(f"**Year** : {year}")
with col2:
    st.subheader("About")
    st.markdown("...........")
with st.expander("Subjects"):
    st.write("python")
    st.write("Java")
    st.write("C++")
    st.write("JavaScript")
