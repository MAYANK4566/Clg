document.writeln("Check Console Now !!!")
console.log("Hello World in Console.");

let a = 10;
function my() {
    let b = 20;
    console.log(a,b);
}
my()
console.log("A : "+ a);
// console.log("B : "+ b); 
let c = 30;
console.log("C : "+ c);

c = 40;
console.log("C : "+ c);