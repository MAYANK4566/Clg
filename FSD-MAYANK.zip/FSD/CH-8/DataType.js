var x = 16 + 4 + "5";
var z = "3" + 4 + 5;
console.log(x);
console.log(z);
var a = 5
var b = 5.5
var c = "5"
var d = true
var e = null
console.log(typeof(a),typeof(b),typeof(c),typeof(d),typeof(e));
