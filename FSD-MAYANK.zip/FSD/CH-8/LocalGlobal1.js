document.writeln("Check Console Now !!!")
console.log("Hello World in Console.");

const a = 20;
console.log(a);
function my() {
    var b = 100; // Local 
    console.log(b);
    console.log(a);
}
console.log(a);
my()