let btn = document.getElementById("btn")
let para = document.getElementsByClassName("para")

btn.addEventListener("click", () => {
    let m = document.getElementById("marks").value;
    console.log(m);
    
    if(m>70){
        console.log("helloo");
        para.ap
    }
    
})